package com.example.profil_resto;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void pindah(View v) {
        Intent it = new Intent(this, tampilanke2.class);
        startActivity(it);
    }

    public void pindah3(View v) {
        Intent it = new Intent(this, TampilanKe3.class);
        startActivity(it);

    }

    public void pindah4(View v) {
        Intent it = new Intent(this, tampilanke4.class);
        startActivity(it);
    }
}