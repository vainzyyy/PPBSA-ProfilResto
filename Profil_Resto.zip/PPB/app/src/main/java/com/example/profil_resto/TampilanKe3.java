package com.example.profil_resto;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class TampilanKe3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampilanke3);
    }

    public void phonecall(View v) {
        String nomor = "085876850925";

        Intent memanggil = new Intent(Intent.ACTION_DIAL);
        memanggil.setData(Uri.fromParts("tel:",nomor,null));
        startActivity(memanggil);
    }
    public void kembali(View v) {
        finish();
    }
}