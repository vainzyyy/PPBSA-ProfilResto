package com.example.profil_resto;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class tampilanke4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampilanke4);
    }

    public void mapIntent(View v) {
        String nomor = "085876850925";

        Uri uri = Uri.parse("google.streetview:cbll=2C85+WM Pendrikan Kidul, Kota Semarang, Jawa Tengah");
        Intent implicitIntent = new Intent(Intent.ACTION_VIEW, uri);
        startActivity(implicitIntent);
    }
    public void kembali(View v) {
        finish();


    }
}